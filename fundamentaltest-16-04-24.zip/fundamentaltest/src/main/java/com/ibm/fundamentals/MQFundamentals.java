package com.ibm.fundamentals;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MQFundamentals {

	public static void main(String[] args) {

	String dbURL = "jdbc:sqlserver://TP-MI-001\\SQL2022;databaseName=tempdb;user=sa;password=iamfine@123;encrypt=false;";

	//String dbURL = "jdbc:sqlserver://DEV003\\SRV2014ENT;databaseName=tempdb;user=sa;password=iamfine@123;encrypt=true;trustServerCertificate=true;";

	//System.setProperty("jdk.tls.client.protocols", "TLSv1.2");


	printmsg();
	String insertSql = "INSERT INTO tb_mqMsg (msg) VALUES (?) ";
	String message = "Ayesha";
	try(Connection connection = DriverManager.getConnection(dbURL)){

	        System.out.println("connection established");
PreparedStatement prepsInsertProduct = connection.prepareStatement(insertSql);
	    		// Set the dynamic variable as the value of the parameter

	    		prepsInsertProduct.setString(1, message);

	    		prepsInsertProduct.execute();

	    		           // Retrieve the generated key from the insert.

	    		           ResultSet resultSet = prepsInsertProduct.getGeneratedKeys();




	    		           // Print the ID of the inserted row.

	    		           while (resultSet.next()) {

	    		               System.out.println("Generated: " + resultSet.getString(1));

	    		           }
	       } catch (SQLException e) {

	        System.out.println("error is=>"+e);

	           e.printStackTrace();

	       }
	       
	}
	
	public static void printmsg() {
		System.out.println("Here you go!!!");
	}
	
	}
	
	



