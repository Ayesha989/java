package com.ibm.fundamentals;

import javax.jms.JMSContext;

import javax.jms.JMSException;

import javax.jms.JMSProducer;

import javax.jms.ObjectMessage;

import javax.jms.Queue;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.activemq.artemis.jms.client.ActiveMQConnectionFactory;

import javax.naming.InitialContext;

public class MessageProducer {

	public static void main(String[] args) throws NamingException {
		
		InitialContext initialContext = new InitialContext();

		Queue requestqueue = (Queue)initialContext.lookup("queue/requestQueue");



		try(ActiveMQConnectionFactory cf = new ActiveMQConnectionFactory();

		JMSContext jmsContext = cf.createContext(JMSContext.AUTO_ACKNOWLEDGE)){


		JMSProducer producer = jmsContext.createProducer();

		producer.send(requestqueue, "Message 17");

		System.out.println("message has been pushed into queue");

	}
	}
}
