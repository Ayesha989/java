package com.ibm.fundamentals;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.jms.JMSConsumer;
import javax.jms.JMSContext;
import javax.jms.JMSException;
import javax.jms.Queue;
import javax.jms.TextMessage;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.activemq.artemis.jms.client.ActiveMQConnectionFactory;

public class MessageConsumer {

	public static void main(String[] args) throws NamingException {

		InitialContext initialContext = new InitialContext();

		Queue requestqueue = (Queue)initialContext.lookup("queue/requestQueue");

		//String connectionUrl =

		             // "jdbc:sqlserver://DEV003\\SRV2014ENT"

		                 //      + "database=tempdb;"

		                   //    + "user=sa;"

		                   //    + "password=iamfine@123;"

		                   //    + "encrypt=true;"

		                     //  + "trustServerCertificate=false;"

		                     //  + "loginTimeout=30;";

		//ResultSet resultSet = null;

		String connectionUrl = "jdbc:sqlserver://TP-MI-001\\SQL2022;databaseName=tempdb;user=sa;password=iamfine@123;encrypt=false;";

		try(ActiveMQConnectionFactory cf = new ActiveMQConnectionFactory();

		JMSContext jmsContext = cf.createContext()){

		JMSConsumer consumer = jmsContext.createConsumer(requestqueue);

		TextMessage message = (TextMessage) consumer.receive();

		System.out.println("Message in queue=> "+message.getText());

		String insertSql = "INSERT INTO tb_mqMsg (msg) VALUES (?) ";

		try (Connection connection = DriverManager.getConnection(connectionUrl);

		PreparedStatement prepsInsertProduct = connection.prepareStatement(insertSql, Statement.RETURN_GENERATED_KEYS)) {

		// Set the dynamic variable as the value of the parameter

		prepsInsertProduct.setString(1, message.getText());

		prepsInsertProduct.execute();

		           // Retrieve the generated key from the insert.

		           ResultSet resultSet = prepsInsertProduct.getGeneratedKeys();
		           // Print the ID of the inserted row.

		           while (resultSet.next()) {

		               System.out.println("Generated Id: " + resultSet.getString(1));

		           }

		       }

		       // Handle any errors that may have occurred.

		       catch (SQLException e) {

		           e.printStackTrace();

		       }    

		} catch (JMSException e) {

		// TODO Auto-generated catch block

		e.printStackTrace();

		}

	}
	


}
