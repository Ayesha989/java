package com.ibm.fundamentals;

import javax.jms.JMSContext;
import javax.jms.JMSProducer;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.activemq.artemis.jms.client.ActiveMQConnectionFactory;

public class MQXmlProducer {

	public static void main(String[] args) throws NamingException {
		// TODO Auto-generated method stub

		InitialContext initialContext = new InitialContext();

		Queue requestqueue = (Queue)initialContext.lookup("queue/requestQueue");



		try(ActiveMQConnectionFactory cf = new ActiveMQConnectionFactory();

		JMSContext jmsContext = cf.createContext(JMSContext.AUTO_ACKNOWLEDGE)){


		JMSProducer producer = jmsContext.createProducer();
		
		
		  int totalBatches = 1; // Set the totalBatches count here


              // Construct the XML message with the BATCH element
              String xmlMessage = generateXMLContentWithMultipleBatches(totalBatches);
           
          TextMessage message = jmsContext.createTextMessage(xmlMessage);
          
          // Send the message to the queue
          producer.send(requestqueue, message);
          System.out.println("Message sent successfully.");
		

		/*String xmlContent = generateXMLContentWithMultipleBatches(3);
        TextMessage message = jmsContext.createTextMessage(xmlContent);
        producer.send(requestqueue,message);
        System.out.println("Message sent successfully.");*/

	}
	}

//Method to generate XML content with multiple batches, each with a unique batch ID
	private static String generateXMLContentWithMultipleBatches(int totalBatches) {
	    StringBuilder xmlBuilder = new StringBuilder();
	   xmlBuilder.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
	   xmlBuilder.append("<root>\n");
	   xmlBuilder.append("<response batchPending=\"0\" totalBatches=\"").append(totalBatches).append("\" bpId=\"IN487875\" isCommAllowed=\"Y\"></response>\n");
	    
	  
	    for (int i = 0; i < totalBatches; i++) {
	    	xmlBuilder.append("<BATCH batchId=\"").append(200000296625L + i).append("\" bpId=\"IN487875\" msgGrp=\"1\" isinCnt=\"1\">\n");
	        xmlBuilder.append("<ISIN id=\"IN0019770059\" instTypCnt=\"1\">\n");
	        xmlBuilder.append("<INSTRS msgType=\"105\" subMsgType=\"203\" instrCnt=\"1\"> \n");
	        xmlBuilder.append("<INSTR>\n");
	        xmlBuilder.append("  <IDTLS>20000000296954##IDD##1007193238####IN000018##IN487875##10013170####IN487875##12179831##00199253####1##########2019-08-09##30##33####Remarks##0##1####1####10988##4##############2##2019-08-01##Preeti Shah##09876655567##HDFC BANK LTD##REF-987655456##1##Y##1</IDTLS>\n");
	        xmlBuilder.append("  <REFDTLS>1000196858##0##########</REFDTLS>\n");
	        xmlBuilder.append("  <ADTDTLS type=\"null\">MANOJM  ##2019-08-09 11:40:13.142##MANOJC  ##2019-08-09 11:40:28.168</ADTDTLS>\n");
	        xmlBuilder.append("</INSTR>\n");
	        xmlBuilder.append("</INSTRS>\n");
	        xmlBuilder.append("</ISIN>\n");
	        xmlBuilder.append("</BATCH>\n");
	        
	    }
	    xmlBuilder.append("</root>");
	    
	    return xmlBuilder.toString();
	}

}
