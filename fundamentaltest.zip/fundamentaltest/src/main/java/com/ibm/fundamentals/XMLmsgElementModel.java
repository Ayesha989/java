package com.ibm.fundamentals;

public class XMLmsgElementModel {
	
	private String batchPending;
    private int totalBatches;
    private String bpId;
    private String isCommAllowed;
    private long batchId;
    private String msgGrp;
    private int isinCnt;
    
	
	
	public String getBatchPending() {
		return batchPending;
	}
	public void setBatchPending(String batchPending) {
		this.batchPending = batchPending;
	}
	public int getTotalBatches() {
		return totalBatches;
	}
	public void setTotalBatches(int totalBatches) {
		this.totalBatches = totalBatches;
	}
	public String getBpId() {
		return bpId;
	}
	public void setBpId(String bpId) {
		this.bpId = bpId;
	}
	public String getIsCommAllowed() {
		return isCommAllowed;
	}
	public void setIsCommAllowed(String isCommAllowed) {
		this.isCommAllowed = isCommAllowed;
	}
	public long getBatchId() {
		return batchId;
	}
	public void setBatchId(long batchId) {
		this.batchId = batchId;
	}
	public String getMsgGrp() {
		return msgGrp;
	}
	public void setMsgGrp(String msgGrp) {
		this.msgGrp = msgGrp;
	}
	public int getIsinCnt() {
		return isinCnt;
	}
	public void setIsinCnt(int isinCnt) {
		this.isinCnt = isinCnt;
	}

	
}
