package com.ibm.fundamentals;

import java.util.List;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MySaxHandler extends DefaultHandler {
	
	// List to hold xml values object
	private XMLmsgElementModel xmlMsgModel;
    private String currentElement;

    public MySaxHandler(XMLmsgElementModel xmlMsgModel) {
        this.xmlMsgModel = xmlMsgModel;
    }
	
	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
		
		 if (qName.equalsIgnoreCase("response")) {
			 //xmlMsgModel = new XMLmsgElementModel();
	        	//String batchPending = attributes.getValue("batchPending");
	        	//xmlMsgModel.setBatchPending(batchPending);
	        	xmlMsgModel.setBatchPending(attributes.getValue("batchPending"));
	        	xmlMsgModel.setTotalBatches(Integer.parseInt(attributes.getValue("totalBatches")));
	        	xmlMsgModel.setBpId(attributes.getValue("bpId"));
	        	xmlMsgModel.setIsCommAllowed(attributes.getValue("isCommAllowed"));
	        } else if ("BATCH".equals(qName)) {
	        	xmlMsgModel.setBatchId(Long.parseLong(attributes.getValue("batchId")));
	        	//xmlMsgModel.setBpId(attributes.getValue("bpId"));
	        	xmlMsgModel.setMsgGrp(attributes.getValue("msgGrp")); // Adjusted to String
	        	xmlMsgModel.setIsinCnt(Integer.parseInt(attributes.getValue("isinCnt")));
	        }
	}
	
	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {
		if (qName.equalsIgnoreCase("response")) {
            //inResponse = false;
        }
	}

	@Override
	public void characters(char ch[], int start, int length) throws SAXException {
		//data.append(new String(ch, start, length));
	}
	

}
