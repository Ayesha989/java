package com.ibm.fundamentals;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.jms.JMSConsumer;
import javax.jms.JMSContext;
import javax.jms.JMSException;
import javax.jms.Queue;
import javax.jms.TextMessage;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import org.xml.sax.InputSource;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.SAXException;

import java.io.IOException;
import java.io.StringReader;

import com.xml.parser.fundamentals.SaxHandler;

import org.apache.activemq.artemis.jms.client.ActiveMQConnectionFactory;
import org.xml.sax.SAXException;

public class MQXmlConsumer {

	public static void main(String[] args) throws NamingException {
		InitialContext initialContext = new InitialContext();

		Queue requestqueue = (Queue)initialContext.lookup("queue/requestQueue");

		//String connectionUrl = "jdbc:sqlserver://TP-MI-001\\SQL2022;databaseName=tempdb;user=sa;password=iamfine@123;encrypt=false;";

		try(ActiveMQConnectionFactory cf = new ActiveMQConnectionFactory();

		JMSContext jmsContext = cf.createContext()){

		JMSConsumer consumer = jmsContext.createConsumer(requestqueue);

		TextMessage message = (TextMessage) consumer.receive();

		System.out.println("Message in queue=> "+message.getText());
		
		//XMLmsgElementModel xmlMessage = new XMLmsgElementModel();
		XMLmsgElementModel xmlMessage = parseXML(message);
        printResponseBatch(xmlMessage);

		/*String insertSql = "INSERT INTO tb_mqMsg (msg) VALUES (?) ";

		try (Connection connection = DriverManager.getConnection(connectionUrl);

		PreparedStatement prepsInsertProduct = connection.prepareStatement(insertSql, Statement.RETURN_GENERATED_KEYS)) {

		// Set the dynamic variable as the value of the parameter

		prepsInsertProduct.setString(1, message.getText());

		prepsInsertProduct.execute();

		           // Retrieve the generated key from the insert.

		           ResultSet resultSet = prepsInsertProduct.getGeneratedKeys();
		           // Print the ID of the inserted row.

		           while (resultSet.next()) {

		               System.out.println("Generated Id: " + resultSet.getString(1));

		           }

		       }

		       // Handle any errors that may have occurred.

		       catch (SQLException e) {

		           e.printStackTrace();

		       }   */ 

		} catch (JMSException e) {

		// TODO Auto-generated catch block

		e.printStackTrace();

		}

	}//main method closing
	
	private static XMLmsgElementModel parseXML(TextMessage message) {
		XMLmsgElementModel xmlMessage = new XMLmsgElementModel();
	    
	    try {
	        String xmlContent = message.getText();
	        //System.out.println("XML Content => "+xmlContent);
	        SAXParserFactory factory = SAXParserFactory.newInstance();
	        SAXParser saxParser = factory.newSAXParser();
	        MySaxHandler handler = new MySaxHandler(xmlMessage);
	        try {
	            saxParser.parse(new InputSource(new StringReader(xmlContent)), handler);
	        } catch (SAXException | IOException e) {
	            e.printStackTrace();
	        }
	        //saxParser.parse(new InputSource(new StringReader(xmlContent)), handler);
	    } catch (ParserConfigurationException | SAXException  | JMSException e) {
	        e.printStackTrace();
	    }
	    return xmlMessage;
	}

	private static void printResponseBatch(XMLmsgElementModel xmlMessage) {
		System.out.println("ResponseBatch:");
        System.out.println("batchPending: " + xmlMessage.getBatchPending());
        System.out.println("totalBatches: " + xmlMessage.getTotalBatches());
        System.out.println("bpId: " + xmlMessage.getBpId());
        System.out.println("isCommAllowed: " + xmlMessage.getIsCommAllowed());
        System.out.println("batchId: " + xmlMessage.getBatchId());
        System.out.println("msgGrp: " + xmlMessage.getMsgGrp());
        System.out.println("isinCnt: " + xmlMessage.getIsinCnt());
		
	}

	

}
