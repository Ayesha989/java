package com.xml.parser.fundamentals;

import java.util.jar.Attributes;

import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

import com.ibm.fundamentals.XMLmsgElementModel;

public class SaxHandler extends DefaultHandler {
       
	private XMLmsgElementModel xmlMessage;
    private String currentElement;

    public SaxHandler(XMLmsgElementModel xmlMessage) {
        this.xmlMessage = xmlMessage;
    }

    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        currentElement = qName;
        if (qName.equalsIgnoreCase("response")) {
        	String batchPending = attributes.getValue("batchPending");
        	xmlMessage.setBatchPending(batchPending);
        	xmlMessage.setBatchPending(attributes.getValue("batchPending"));
        	xmlMessage.setTotalBatches(Integer.parseInt(attributes.getValue("totalBatches")));
        	xmlMessage.setBpId(attributes.getValue("bpId"));
        	xmlMessage.setIsCommAllowed(attributes.getValue("isCommAllowed"));
        } else if ("BATCH".equals(qName)) {
        	xmlMessage.setBatchId(Long.parseLong(attributes.getValue("batchId")));
        	xmlMessage.setBpId(attributes.getValue("bpId"));
        	xmlMessage.setMsgGrp(attributes.getValue("msgGrp")); // Adjusted to String
        	xmlMessage.setIsinCnt(Integer.parseInt(attributes.getValue("isinCnt")));
        }
    }
    
    @Override
    public void error(SAXParseException e) throws SAXException {
        // Handle non-fatal errors here
        System.err.println("Error parsing XML: " + e.getMessage());
    }

    @Override
    public void fatalError(SAXParseException e) throws SAXException {
        // Handle fatal errors here
        System.err.println("Fatal error parsing XML: " + e.getMessage());
    }
}



